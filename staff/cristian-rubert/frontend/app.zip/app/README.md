# App

## Intro

Social app for ... ?

## Functional Description

User
- register
- login
